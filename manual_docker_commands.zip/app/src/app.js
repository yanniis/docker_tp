const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
const port = 4743;

const dbConfig = {
	host: 'mysql_container',
	port: 5655,
	user: 'root',
	password: 'example',
	database: 'testdb',
};

app.get('/health', (req, res) => {
	res.status(200).json({ status: 'healthy' });
});

// {"error":"Table 'testdb.test_data' doesn't exist"} signifie bien que la connexion à la base de données est bonne
// mais que la table test_data n'existe pas

app.get('/data', async (req, res) => {
	try {
		const connection = await mysql.createConnection(dbConfig);
		const [rows] = await connection.execute('SELECT * FROM test_data');
		res.json(rows);
		connection.end();
	} catch (err) {
		res.status(500).json({ error: err.message });
	}
});

app.listen(port, () => {
	console.log(`App running on port ${port}`);
});
